#install shiny & openxlsx
library(shinyBS)
library(shiny)
library(openxlsx)
library(DT)
library(shinyWidgets)
library(openxlsx)
library(ggplot2)
library(ggpubr)
library(lubridate)
library(shinydashboard)
# template data

template<- data.frame(
  count = c(1,2,3,4,5,6,7,8,9,10),
  name = c(""),
  surname =  c(""),
  date_of_birth= c(""), 
  salary = c(""),
  position = c(""),
  seniority_level = c(""),
  team =  c(""),
  agreement_type = c(""),
  sex = c(""),
  date_of_employment = c(""),
  experience = c(""),
  hours_of_training = c(""))

########

# minimal Shiny UI
ui <- fluidPage(
  setBackgroundColor(color = "#2C346B"), 
  tags$style(HTML("
    .tabbable > .nav > li > a                  {background-color: grey;  color:black;font-family:courier new}
    .tabbable > .nav > li > a[data-value='t1'] {background-color: grey;   color:black; font-family:courier new}
    .tabbable > .nav > li > a[data-value='t2'] {background-color: grey;  color:black; font-family:courier new}
    .tabbable > .nav > li > a[data-value='t3'] {background-color: grey; color:black; font-family:courier new}
    .tabbable > .nav > li[class=active]    > a {background-color: #FFF559; color:black;font-family:courier new}
")),
  titlePanel(
    title = div(img(src="small.jpg", height = '70px', width = '150px'), style="background-color: #2C346B;")
),

tabsetPanel(type = "pills",
  tabPanel("Homepage", 
           fluidRow(
             column(width = 5, offset = 1,
                    p(HTML("<br> Welcome to Henkilo! We are happy to have you here. <br><br> Henkilo is a human-centric HR resource planning application that allows you
                    to get a quick overview into the financial impact of your human resources. 
                           Download your data in the <i> Data Import </i> tab and view your analysis in the <i> Summary</i> tab"), style = "color:#FFF559; font-size:18px; font-family:courier new")
             ),
             column(width = 3, offset = 1,
                    div(img(src="Cat astronaut-cuate.png", height = '400px', width = '400px')))
             )
           ) ,
  tabPanel("Data Import",
           sidebarPanel(h3("Export Template"),
                        downloadButton(
                          "import_template", 
                          "Import Template"
                        ),
                        fileInput("file",h3("Import File"),
                                  accept = c(
                                    "text/csv",
                                    "text/comma-separated-values,text/plain",
                                    ".csv")),
           ),
           mainPanel(p(HTML("ANALYSES"),style = "color:#FFF559; font-size:18px; font-family:courier new"),
                     div(DT::dataTableOutput("sample_table"),style = "width: 100%; background-color:white;"),
)
           ),
  tabPanel("Summary", sidebarPanel(actionButton("show", "Tax scenarios"),
                                   selectInput("var", label = "",
                                               choices = c("No tax", "Genovia", "Panem"),
                                               selected = "Genovia"),
                                   selectInput("currency", label = "Select your currency",
                                               choices = c("USD", "PLN", "EUR"),
                                               selected = "EUR")),
           mainPanel(radioGroupButtons(
             inputId = "Plot_type",
             label = "",
             choices = c("Salary by Position", "Salary by Team", "Salary by Seniority level", "Employer's Tax", "Effect of currency exchange"),
             justified = FALSE,
             selected = "Salary by Position"),
             plotOutput("Plot", height = 400))),
  tabPanel("Table", tableOutput("table"))
))

# minimal Shiny server
server <- function(input, output) {
  observeEvent(input$show, {
    showModal(modalDialog(
      title = "Tax Scenarios",
      h2("No Tax"),
      "A scenario without any tax will be shown.",
      h2("Genovia"),
      "A scenario with progressive tax will be shown.",
      HTML("<hr><strong> Income tax by age</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i> Ages between 25-60 </i></td>
    <td>25%</td>
  </tr>
  <tr>
    <td> <i> Ages below 25 </i></td>
    <td>5%</td>
  </tr>
  <tr>
    <td> <i> Ages above 60 </i></td>
    <td>10%</td>
  </tr>
</table>'),
      HTML("<hr><strong> Income tax by income</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i>  Below 1000 diamonds </i></td>
    <td>5%</td>
  </tr>
  <tr>
    <td> <i> Between 1000 - 7000 diamonds </i></td>
    <td>25%</td>
  </tr>
  <tr>
    <td> <i> Above 7000 diamonds </i></td>
    <td>40% on the difference</td>
  </tr>
</table>'),
      HTML("<hr><strong> Income tax by agreement</strong><br>"),
      "If the employee is employed under regular employee contract, regular income tax will be applied. However if it is a B2B contract, a constant rate of 15% is applied and the employee is not entitled to health benefits.",
      HTML("<hr><strong>Employer's tax</strong> <br>"),
      "Employer's tax depends on the investment to training. If the hours of training per employee exceed 50h per year, 7% tax on employer's revenues will be applied. Else, the common rate of 10% is applied",
      h2("Panem"),
      "A scenario with crazy tax",
      HTML("<hr><strong> Income tax by income</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i> Income < 1000 diamonds </i></td>
    <td>25%</td>
  </tr>
  <tr>
    <td> <i> Income between 1000-5000 diamonds </i></td>
    <td>50%</td>
  </tr>
  <tr>
    <td> <i> Income >5000 diamonds </i></td>
    <td>75%</td>
  </tr>
</table>'),
      HTML("<hr><strong> Income tax lenght of employemnt</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i> Length of employment < 3y </i></td>
    <td>No tax reductions</td>
  </tr>
  <tr>
    <td> <i> For every year of employment after 3y </i></td>
    <td>1% reduction in tax</td>
  </tr>
</table>'),
      HTML("<hr><strong> Employer's tax</strong>"),
      "The employer receives an additional 5% tax on revenues will be applied if more than 60% of the employees are of one gender.",
      easyClose = TRUE
    ))
  })
  output$import_template <- downloadHandler(
    filename = function() {
      "employee_data.xlsx"
    },
    content = function(file) {
      workbook <- createWorkbook()
     #Workbook ######
      
      addWorksheet(
        wb = workbook,
        sheetName = "Employee Data"
      )
      
      setColWidths(
        workbook,
        1,
        cols = 1:13,
        widths = c(6, 12, 18, 15, 8, 10, 12, 8, 15, 6, 18, 12,25)
      )
      
      writeData(
        workbook,
        sheet = 1,
        c("Employee Data"),
        startRow = 1,
        startCol = 1
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fontSize = 20,
          textDecoration = "bold"
        ),
        rows = 1,
        cols = 1
      )
      
      writeData(
        workbook,
        sheet = 1,
        template,
        startRow = 3,
        startCol = 1
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#1a5bc4",
          halign = "center",
          fontColour = "#ffffff"
        ),
        rows = 3,
        cols = 1:13,
        gridExpand = TRUE
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#d8d8d8",
          numFmt = "comma"
        ),
        rows = seq(from=4, to =100 , by=2),
        cols = 1:13,
        gridExpand = TRUE
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#9ed7ff",
          numFmt = "comma"
        ),
        rows = seq(from=5, to =101 , by=2),
        cols = 1:13,
        gridExpand = TRUE
      )
      #######
      saveWorkbook(workbook, file)
    })


  # formData <- reactive({
  #  read.csv(input$file,header = TRUE )
  #  })
  
  #  output$hist <- renderPlot({
  #    d<-na.omit(input$file)
  #    plot(d[,2],d[,3])
  #  })
  
  df_products_upload <- reactive({
    inFile <- input$file
    if (is.null(inFile))
      return(NULL)
    df <- read.csv(inFile$datapath, header = TRUE,sep = ",")
    return(df)
  })
  
  output$sample_table<- DT::renderDataTable({
    df <- df_products_upload()

    DT::datatable(df[,c(1:5)])
  })
  # output$Position_Salary_Plot 
  my_function<- reactive({
    df <- df_products_upload()
    scenario <- input$var
    df$date_of_birth <- as.Date(df$date_of_birth, "%m/%d/%Y")
    df$date_of_employment <- as.Date(df$date_of_employment, "%m/%d/%Y")
    df$experience <- as.numeric(df$experience)
    df$hours_of_training<- as.numeric(df$experience)
    df$salary<- as.numeric(df$salary)
    if(scenario=='Genovia'){
      salary_after_tax_1 <- NA
      salary_after_tax_1<-ifelse(df$salary <1000, df$salary * 0.95,
                                 ifelse(df$salary >= 1000 & df$salary <= 7000,df$salary * 0.75, df$salary * 0.6))
      today = as.Date(today())
      df$age <- NA
      df$age <-trunc((as.Date(df$date_of_birth) %--% today) / years(1))
      salary_after_tax_2 <-NA
      salary_after_tax_2<-ifelse(df$age <25, df$salary * 0.95,
                                 ifelse(df$age > 60,df$salary * 0.90, df$salary * 0.75 ))
      salary_after_tax = c()
      for (row in 1:nrow(df)){
        x <- NA
        x <- ifelse(df[row,9] == "B2B", df[row,5]* 0.85, min(salary_after_tax_1[row], salary_after_tax_2[row]))
        salary_after_tax <- c(salary_after_tax,x)
      }
      df$salary_after_tax <- salary_after_tax
    }
    if(scenario=='Panem'){
      df$salary_after_tax <- panem_salary(df)
    }
    if(scenario=='No tax'){
      df$salary_after_tax <- df$salary
    }
    return(df)
  })
  et_function<- reactive({
    df <- my_function()
    scenario <- input$var
    if(scenario=='Genovia'){
      employer_tax <- ifelse(mean(df$hours_of_training)> 50, 0.07, 0.1)
    }
    if(scenario=='Panem'){
      employer_tax <- ifelse((length(which(df$sex == "M"))/length(which(df$sex == "F")))> 0.6, 0.05, 0)
    }
    if(scenario=='No tax'){
      employer_tax = 0
    }
    return(employer_tax)
  })
  
  output$Plot <- renderPlot({
    df <- my_function()
    et<- et_function()
    if (input$Plot_type %in% "Salary by Position") {
    after_tax_mean<- aggregate(df$salary_after_tax, list(df$position), FUN=mean)
    ggplot(after_tax_mean, aes(x=reorder(after_tax_mean$Group.1, -after_tax_mean$x), y=after_tax_mean$x)) + 
      geom_bar(stat="identity", width=.5, fill="#2C346B") + 
      labs(subtitle="Average salary after tax deductions by Position") + 
      theme(axis.text.x = element_text(size = 10, angle = 70, vjust = 0.5, hjust=1),
            axis.title.x = element_blank(),
            axis.title.y = element_blank())
    }
    else if (input$Plot_type %in% "Salary by Team") {
      after_tax_mean_team<- aggregate(df$salary_after_tax, list(df$team), FUN=mean)
      ggplot(after_tax_mean_team, aes(x=reorder(after_tax_mean_team$Group.1, -after_tax_mean_team$x), y=after_tax_mean_team$x)) + 
        geom_bar(stat="identity", width=.5, fill="#2C346B") + 
        labs(subtitle="Average salary after tax deductions by Team") + 
        theme(axis.text.x = element_text(size = 10, angle = 70, vjust = 0.5, hjust=1),
              axis.title.x = element_blank(),
              axis.title.y = element_blank())
    }
    else if (input$Plot_type %in% "Salary by Seniority level"){
      after_tax_mean_sen<- aggregate(df$salary_after_tax, list(df$seniority_level), FUN=mean)
      ggplot(after_tax_mean_sen, aes(x=reorder(after_tax_mean_sen$Group.1, -after_tax_mean_sen$x), y=after_tax_mean_sen$x)) + 
        geom_bar(stat="identity", width=.5, fill="#2C346B") + 
        labs(subtitle="Average salary after tax deductions by Seniority Level") + 
        theme(axis.text.x = element_text(size = 10, angle = 70, vjust = 0.5, hjust=1),
              axis.title.x = element_blank(),
              axis.title.y = element_blank())
    }
    else if (input$Plot_type %in% "Employer's Tax"){
      df_pie <- data.frame(
        group = c("Profit", "Tax"),
        value = c(1-et, et)
      )
      ggplot(df_pie, aes(x="", y=value, fill=group)) +
        geom_bar(stat="identity", width=1) +
        coord_polar("y", start=0) + 
        scale_fill_manual(values=c("#2C346B", "#FFF559"))+
        theme(axis.text.x = element_blank(),
              axis.text.y = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_blank())
    }
  })
  
}
shinyApp(ui, server)
