#install shiny & openxlsx
library(shinyBS)
library(shiny)
library(openxlsx)
library(DT)
library(shinyWidgets)
library(openxlsx)
library(ggplot2)
library(ggpubr)
library(lubridate)
# template data

template<- data.frame(
  count = c(1,2,3,4,5,6,7,8,9,10),
  name = c(""),
  surname =  c(""),
  date_of_birth= c(""), 
  salary = c(""),
  position = c(""),
  seniority_level = c(""),
  team =  c(""),
  agreement_type = c(""),
  sex = c(""),
  date_of_employment = c(""),
  experience = c(""),
  hours_of_training = c(""))

#Functions#######
#####Genovia
dataframe_convert <- function(file){
  data <- read.xlsx(file)
  data$date_of_birth <- as.Date(data$date_of_birth, origin = "1899-12-30")
  data$date_of_employment <- as.Date(data$date_of_employment, origin = "1899-12-30")
}
genovia_salary <- function(dataframe){
  salary_after_tax_1<-ifelse(dataframe$salary <1000, dataframe$salary * 0.95,
                             ifelse(dataframe$salary >= 1000 & dataframe$salary <= 7000,dataframe$salary * 0.75, dataframe$salary * 0.6 ))
  today = as.Date(today())
  dataframe$age <-trunc((as.Date(dataframe$date_of_birth) %--% today) / years(1))
  salary_after_tax_2<-ifelse(dataframe$age <25, dataframe$salary * 0.95,
                             ifelse(dataframe$salary > 60,dataframe$salary * 0.90, dataframe$salary * 0.75 ))
  salary_after_tax = c()
  for (row in 1:nrow(dataframe)){
    x <- ifelse(dataframe[row,9] == "B2B", dataframe[row,5]* 0.85, min(salary_after_tax_1[row], salary_after_tax_2[row]))
    salary_after_tax <- c(salary_after_tax,x)
  }
  return(salary_after_tax)
}
  genovia_employer<- function(dataframe){
    employer_tax <- ifelse(mean(dataframe$hours_of_training)> 50, 0.07, 0.1)
    return(employer_tax)
  }
#####Panem
  panem_salary <- function(dataframe){
    dataframe$salary_after_tax_1<-ifelse(dataframe$salary <1000, dataframe$salary * 0.75,
                                         ifelse(dataframe$salary >= 1000 & dataframe$salary <= 5000,dataframe$salary * 0.5, dataframe$salary * 0.25 ))
    today = as.Date(today())
    dataframe$length_of_employment <-as.numeric(trunc((as.Date(dataframe$date_of_employment) %--% today) / years(1)))
    dataframe$salary_after_tax_2<-ifelse(dataframe$length_of_employment <3, 
                                         dataframe$salary_after_tax_1,
                                         (dataframe$salary_after_tax_1/dataframe$salary + (dataframe$length_of_employment/100))*dataframe$salary)
    return(dataframe$salary_after_tax_2)
  }
  panem_employer<- function(dataframe){
    employer_tax <- ifelse((length(which(dataframe$sex == "M"))/length(which(dataframe$sex == "F")))> 0.6, 0.05, 0)
    return(employer_tax)
  }
#Visualisations#############
  tax_scenario_visualisation <- function(dataframe, scenario){
    dataframe$salary_after_tax <- ifelse(scenario == "Genovia", genovia_salary(dataframe),
                                         ifelse(scenario == "Panem",panem_salary(dataframe),dataframe$salary))
    no_tax <- ggplot(dataframe, aes(x=reorder(position, -salary), y=salary)) + 
      geom_bar(stat="summary", fun= "mean", width=.5, fill="grey") + 
      labs(subtitle="Salary before tax deductions vs Position") + 
      theme(axis.text.x = element_text(size =5),
            axis.title.x = element_blank(),
            axis.title.y = element_blank())
    tax<- ggplot(dataframe, aes(x=reorder(position, -dataframe$salary_after_tax), y=dataframe$salary_after_tax)) + 
      geom_bar(stat="summary", fun= "mean", width=.5, fill="#2C346B") + 
      labs(subtitle="Salary before after tax deductions vs Position") + 
      theme(axis.text.x = element_text(size = 5),
            axis.title.x = element_blank(),
            axis.title.y = element_blank())
    ggarrange(no_tax, tax + font("x.text", size = 10),ncol = 1, nrow = 2)
  }
########

# minimal Shiny UI
ui <- fluidPage(
  setBackgroundColor(color = "#2C346B"), 
  tags$style(HTML("
    .tabbable > .nav > li > a                  {background-color: grey;  color:black;font-family:courier new}
    .tabbable > .nav > li > a[data-value='t1'] {background-color: grey;   color:black; font-family:courier new}
    .tabbable > .nav > li > a[data-value='t2'] {background-color: grey;  color:black; font-family:courier new}
    .tabbable > .nav > li > a[data-value='t3'] {background-color: grey; color:black; font-family:courier new}
    .tabbable > .nav > li[class=active]    > a {background-color: #FFF559; color:black;font-family:courier new}
  ")),
  titlePanel(
    title = div(img(src="small.jpg", height = '70px', width = '150px'), style="background-color: #2C346B;")
),

tabsetPanel(type = "pills",
  tabPanel("Homepage", 
           fluidRow(
             column(width = 5, offset = 1,
                    p(HTML("<br> Welcome to Henkilo! We are happy to have you here. <br><br> Henkilo is a human-centric HR resource planning application that allows you
                    to get a quick overview into the financial impact of your human resources. 
                           Download your data in the <i> Data Import </i> tab and view your analysis in the <i> Summary</i> tab"), style = "color:#FFF559; font-size:18px; font-family:courier new")
             ),
             column(width = 3, offset = 1,
                    div(img(src="Cat astronaut-cuate.png", height = '400px', width = '400px')))
             )
           ) ,
  tabPanel("Data Import",
           sidebarPanel(h3("Export Template"),
                        downloadButton(
                          "import_template", 
                          "Import Template"
                        ),
                        fileInput("file",h3("Import File"),
                                  accept = c(
                                    "text/csv",
                                    "text/comma-separated-values,text/plain",
                                    ".csv")),
           ),
           mainPanel(p(HTML("ANALYSES"),style = "color:#FFF559; font-size:18px; font-family:courier new"),
                     DT::dataTableOutput("sample_table"),
                     actionButton("show", "Tax scenarios"),
                     selectInput("var", 
                                 label = p(HTML("Select the tax scenario"), style = "color:#FFF559; font-size:12px; font-family:courier new"),
                                 choices = c("No tax", "Genovia", "Panem"),
                                 selected = "No tax")
           ),
           
           
  ),
  tabPanel("Summary", sidebarPanel(tags$style(".well {background-color:rgba(169,169,169,0.5)}; outline: none"), tabsetPanel(type = "pills",
                                  tabPanel("Salary by Position"),# data <- dataframe_convert( "C:\\Users\\serei\\Downloads\\employee_data2.xlsx"), tax_scenario_visualisation(data, "Genovia")),
                                  tabPanel("Salary by Team"))))),
  tabPanel("Table", tableOutput("table"))
)

# minimal Shiny server
server <- function(input, output) {
  observeEvent(input$show, {
    showModal(modalDialog(
      title = "Tax Scenarios",
      ##########
      h2("No Tax"),
      "A scenario without any tax will be shown.",
      h2("Genovia"),
      "A scenario with progressive tax will be shown.",
      HTML("<hr><strong> Income tax by age</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i> Ages between 25-60 </i></td>
    <td>25%</td>
  </tr>
  <tr>
    <td> <i> Ages below 25 </i></td>
    <td>5%</td>
  </tr>
  <tr>
    <td> <i> Ages above 60 </i></td>
    <td>10%</td>
  </tr>
</table>'),
      HTML("<hr><strong> Income tax by income</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i>  Below 1000 diamonds </i></td>
    <td>5%</td>
  </tr>
  <tr>
    <td> <i> Between 1000 - 7000 diamonds </i></td>
    <td>25%</td>
  </tr>
  <tr>
    <td> <i> Above 7000 diamonds </i></td>
    <td>40% on the difference</td>
  </tr>
</table>'),
      HTML("<hr><strong> Income tax by agreement</strong><br>"),
      "If the employee is employed under regular employee contract, regular income tax will be applied. However if it is a B2B contract, a constant rate of 15% is applied and the employee is not entitled to health benefits.",
      HTML("<hr><strong>Employer's tax</strong> <br>"),
      "Employer's tax depends on the investment to training. If the hours of training per employee exceed 50h per year, 7% tax on employer's revenues will be applied. Else, the common rate of 10% is applied",
      h2("Panem"),
      "A scenario with crazy tax",
      HTML("<hr><strong> Income tax by income</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i> Income < 1000 diamonds </i></td>
    <td>25%</td>
  </tr>
  <tr>
    <td> <i> Income between 1000-5000 diamonds </i></td>
    <td>50%</td>
  </tr>
  <tr>
    <td> <i> Income >5000 diamonds </i></td>
    <td>75%</td>
  </tr>
</table>'),
      HTML("<hr><strong> Income tax lenght of employemnt</strong>"),
      HTML('<table style="width:100%">
  <tr>
    <td> <i> Length of employment < 3y </i></td>
    <td>No tax reductions</td>
  </tr>
  <tr>
    <td> <i> For every year of employment after 3y </i></td>
    <td>1% reduction in tax</td>
  </tr>
</table>'),
      HTML("<hr><strong> Employer's tax</strong>"),
      "The employer receives an additional 5% tax on revenues will be applied if more than 60% of the employees are of one gender.",
      easyClose = TRUE
    ))
    ########
  })
  output$import_template <- downloadHandler(
    filename = function() {
      "employee_data.xlsx"
    },
    content = function(file) {
      workbook <- createWorkbook()
     #Workbook ######
      
      addWorksheet(
        wb = workbook,
        sheetName = "Employee Data"
      )
      
      setColWidths(
        workbook,
        1,
        cols = 1:13,
        widths = c(6, 12, 18, 15, 8, 10, 12, 8, 15, 6, 18, 12,25)
      )
      
      writeData(
        workbook,
        sheet = 1,
        c("Employee Data"),
        startRow = 1,
        startCol = 1
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fontSize = 20,
          textDecoration = "bold"
        ),
        rows = 1,
        cols = 1
      )
      
      writeData(
        workbook,
        sheet = 1,
        template,
        startRow = 3,
        startCol = 1
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#1a5bc4",
          halign = "center",
          fontColour = "#ffffff"
        ),
        rows = 3,
        cols = 1:13,
        gridExpand = TRUE
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#d8d8d8",
          numFmt = "comma"
        ),
        rows = seq(from=4, to =100 , by=2),
        cols = 1:13,
        gridExpand = TRUE
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#9ed7ff",
          numFmt = "comma"
        ),
        rows = seq(from=5, to =101 , by=2),
        cols = 1:13,
        gridExpand = TRUE
      )
      #######
      saveWorkbook(workbook, file)
    }
  )
  observeEvent(input$var, {tax_scenario <- if(input$var == "No Tax"){
      "No Tax"
    }else if (input$var == "Genovia"){
      "Genovia"
    }
    else{
      "Panem"
    }})

  # formData <- reactive({
  #  read.csv(input$file,header = TRUE )
  #  })
  
  #  output$hist <- renderPlot({
  #    d<-na.omit(input$file)
  #    plot(d[,2],d[,3])
  #  })
  
  df_products_upload <- reactive({
    inFile <- input$file
    if (is.null(inFile))
      return(NULL)
    df <- read.csv(inFile$datapath, header = TRUE,sep = ",")
    return(df)
  })
  
  output$sample_table<- DT::renderDataTable({
    df <- df_products_upload()
    DT::datatable(df[,c(1:5)])
  })
  
  
}
shinyApp(ui, server)