library(httr)

getInfoInJson <- httr::GET('http://api.nbp.pl/api/exchangerates/tables/a/', 
                          accept_json())

#safe the info in a json object 
jsonInfoImg <- content(getInfoInJson, type="application/json")

for (i in 1:100){
  jsonInfoImg[[1]][4]
  }

