#install shiny & openxlsx

library(shiny)
library(openxlsx)
library(DT)
# template data

template<- data.frame(
  count = c(1,2,3,4,5,6,7,8,9,10),
  name = c(""),
  surname =  c(""),
  date_of_birth= c(""), 
  salary = c(""),
  position = c(""),
  seniority_level = c(""),
  team =  c(""),
  agreement_type = c(""),
  sex = c(""),
  date_of_employment = c(""),
  experience = c(""),
  hours_of_training = c(""))

# minimal Shiny UI
ui <- fluidPage(
  div(titlePanel("Welcome to Henkilo App"), style="background-color: #e6f2ff;"),
  
    sidebarPanel(h3("Export Template"),
        downloadButton(
          "import_template", 
          "Import Template"
        ),
    fileInput("file",h3("Import File"),
              accept = c(
                "text/csv",
                "text/comma-separated-values,text/plain",
                ".csv")),
      ),
    mainPanel("ANALYSES",
              DT::dataTableOutput("sample_table")
              )
  

)

# minimal Shiny server
server <- function(input, output) {
  
  output$import_template <- downloadHandler(
    filename = function() {
      "employee_data.xlsx"
    },
    content = function(file) {
      workbook <- createWorkbook()
      
      addWorksheet(
        wb = workbook,
        sheetName = "Employee Data"
      )
      
      setColWidths(
        workbook,
        1,
        cols = 1:13,
        widths = c(6, 12, 18, 15, 8, 10, 12, 8, 15, 6, 18, 12,25)
      )
      
      writeData(
        workbook,
        sheet = 1,
        c("Employee Data"),
        startRow = 1,
        startCol = 1
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fontSize = 20,
          textDecoration = "bold"
        ),
        rows = 1,
        cols = 1
      )
      
      writeData(
        workbook,
        sheet = 1,
        template,
        startRow = 3,
        startCol = 1
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#1a5bc4",
          halign = "center",
          fontColour = "#ffffff"
        ),
        rows = 3,
        cols = 1:13,
        gridExpand = TRUE
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#d8d8d8",
          numFmt = "comma"
        ),
        rows = seq(from=4, to =100 , by=2),
        cols = 1:13,
        gridExpand = TRUE
      )
      
      addStyle(
        workbook,
        sheet = 1,
        style = createStyle(
          fgFill = "#9ed7ff",
          numFmt = "comma"
        ),
        rows = seq(from=5, to =101 , by=2),
        cols = 1:13,
        gridExpand = TRUE
      )
      
      saveWorkbook(workbook, file)
    }
  )
  
 # formData <- reactive({
 #  read.csv(input$file,header = TRUE )
 #  })
  
#  output$hist <- renderPlot({
#    d<-na.omit(input$file)
#    plot(d[,2],d[,3])
#  })
 
  df_products_upload <- reactive({
    inFile <- input$file
    if (is.null(inFile))
      return(NULL)
    df <- read.csv(inFile$datapath, header = TRUE,sep = ",")
    return(df)
  })
  
  output$sample_table<- DT::renderDataTable({
    df <- df_products_upload()
    DT::datatable(df)
  })
  
   
}
shinyApp(ui, server)